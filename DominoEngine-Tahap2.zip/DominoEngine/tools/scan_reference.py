# Reference implementation of the on-device hand scanner (pure integer ops, mirrors the Kotlin port)
from PIL import Image
import numpy as np, sys

def is_cream(r,g,b):
    return r>=165 and g>=165 and b>=125 and (r-b)>=8 and (r-b)<=75 and abs(r-g)<=16

def is_red(r,g,b):
    return r>=80 and r>=g+45 and r>=b+45

def scan(im):
    H,W,_=im.shape
    y_lo=int(H*0.55); y_hi=int(H*0.98)
    bandH=y_hi-y_lo
    # 1) column profile of cream pixels in the lower band
    col=[0]*W
    for y in range(y_lo,y_hi):
        row=im[y]
        for x in range(W):
            r,g,b=row[x]
            if is_cream(r,g,b) or is_red(r,g,b): col[x]+=1
    thr=int(H*0.10)
    runs=[]; x=0
    while x<W:
        if col[x]>=thr:
            s=x
            while x<W and col[x]>=thr: x+=1
            runs.append([s,x-1])
        else: x+=1
    # merge tiny gaps, drop thin runs
    merged=[]
    for r_ in runs:
        if merged and r_[0]-merged[-1][1]<=3: merged[-1][1]=r_[1]
        else: merged.append(r_)
    minW=int(W*0.025)
    tiles=[t for t in merged if t[1]-t[0]+1>=minW]
    out=[]
    for (x0,x1) in tiles:
        w=x1-x0+1
        # 2) vertical extent from the central 60% of the tile width
        cx0=x0+int(w*0.2); cx1=x1-int(w*0.2)
        rows=[]
        for y in range(y_lo,y_hi):
            c=0
            for x in range(cx0,cx1+1):
                r,g,b=im[y][x]
                if is_cream(r,g,b) or is_red(r,g,b): c+=1
            rows.append(c)
        need=(cx1-cx0+1)*0.5
        gap=max(3,int(w*0.12))
        best=None; y=0
        while y<len(rows):
            if rows[y]>=need:
                s_=y; last=y; y+=1
                while y<len(rows) and (rows[y]>=need or y-last<=gap):
                    if rows[y]>=need: last=y
                    y+=1
                if best is None or (last-s_)>(best[1]-best[0]): best=[s_,last]
            else: y+=1
        if best is None: continue
        y0=y_lo+best[0]; y1=y_lo+best[1]; h=y1-y0+1
        out.append(dict(x0=x0,x1=x1,y0=y0,y1=y1,w=w,h=h))
    return out

def count_pips(im,t,half):
    x0,x1,y0,y1,w,h=t['x0'],t['x1'],t['y0'],t['y1'],t['w'],t['h']
    mid=(y0+y1)//2
    ix=int(w*0.08)
    if half==0: ys=y0+int(h*0.10); ye=mid-int(h*0.045)
    else: ys=mid+int(h*0.045); ye=y1-int(h*0.05)
    xs=x0+ix; xe=x1-ix
    hh=ye-ys+1; ww=xe-xs+1
    mask=[[False]*ww for _ in range(hh)]
    for y in range(hh):
        for x in range(ww):
            r,g,b=im[ys+y][xs+x]
            mask[y][x]=is_red(r,g,b)
    seen=[[False]*ww for _ in range(hh)]
    count=0; areas=[]
    for y in range(hh):
        for x in range(ww):
            if mask[y][x] and not seen[y][x]:
                stack=[(y,x)]; seen[y][x]=True
                a=0; minx=maxx=x; miny=maxy=y
                while stack:
                    cy,cx=stack.pop(); a+=1
                    minx=min(minx,cx);maxx=max(maxx,cx);miny=min(miny,cy);maxy=max(maxy,cy)
                    for dy,dx in ((1,0),(-1,0),(0,1),(0,-1)):
                        ny,nx=cy+dy,cx+dx
                        if 0<=ny<hh and 0<=nx<ww and mask[ny][nx] and not seen[ny][nx]:
                            seen[ny][nx]=True; stack.append((ny,nx))
                bw=maxx-minx+1; bh=maxy-miny+1
                aspect=bw/bh
                if a>=0.012*w*w and a<=0.16*w*w and 0.55<=aspect<=1.8 and a>=0.5*bw*bh*0.6:
                    count+=1; areas.append(a)
    return count,areas

if __name__=="__main__":
    im=np.array(Image.open(sys.argv[1]).convert('RGB')).astype(int)
    tiles=scan(im)
    print("tiles found:",len(tiles))
    for t in tiles:
        a,_=count_pips(im,t,0); b,_=count_pips(im,t,1)
        print(t['x0'],t['x1'],t['y0'],t['y1'],"->",a,"|",b)
