package com.domino.engine.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Settings
import android.view.WindowManager
import android.widget.Toast

/** Foreground service yang menjaga panel overlay tetap hidup di atas game. */
class OverlayService : Service() {

    private var controller: OverlayController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (controller == null) {
            if (!createController()) {
                Toast.makeText(
                    applicationContext,
                    "Izin overlay / aksesibilitas belum aktif",
                    Toast.LENGTH_LONG
                ).show()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun createController(): Boolean {
        val budget = getSharedPreferences(PREFS, MODE_PRIVATE).getLong(KEY_BUDGET_MS, 2500L)
        val acc = DominoAccessibilityService.instance
        val ctx: Context
        val type: Int
        if (Settings.canDrawOverlays(this)) {
            ctx = this
            type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else if (acc != null) {
            ctx = acc
            type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        } else {
            return false
        }
        val c = OverlayController(ctx, type, budget) { stopSelf() }
        c.show()
        controller = c
        running = true
        return true
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Domino Engine", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Domino Engine aktif")
            .setContentText("Overlay berjalan. Tap Stop untuk menutup.")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, n)
    }

    override fun onDestroy() {
        controller?.destroy()
        controller = null
        running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.domino.engine.STOP"
        const val PREFS = "domino_engine"
        const val KEY_BUDGET_MS = "budget_ms"
        private const val CHANNEL = "domino_engine_overlay"
        private const val NOTIF_ID = 1001

        @Volatile
        var running: Boolean = false

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, OverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, OverlayService::class.java))
        }
    }
}
