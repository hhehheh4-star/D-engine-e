package com.domino.engine.core

enum class Side { LEFT, RIGHT, FIRST }

data class Move(val tile: Int, val side: Side)

/** Catatan pass: ujung papan DI SAAT pemain itu pass (bukan ujung papan sekarang). */
data class PassRecord(val player: Int, val left: Int, val right: Int)

enum class Phase { HAND_ENTRY, PICK_STARTER, PLAYING, OVER }

enum class EndReason { NONE, EMPTY_HAND, BLOCKED }

/**
 * Keadaan permainan yang DIAMATI. Pemain 0 = kita (P1), searah jarum jam: 1 = kiri, 2 = atas, 3 = kanan.
 * Kartu lawan yang tersembunyi TIDAK pernah disimpan di sini.
 */
data class GameState(
    val phase: Phase = Phase.HAND_ENTRY,
    val myHand: Int = 0,
    val played: Int = 0,
    val left: Int = -1,
    val right: Int = -1,
    val counts: List<Int> = listOf(7, 7, 7, 7),
    val turn: Int = 0,
    val passes: List<PassRecord> = emptyList(),
    val consecutivePasses: Int = 0,
    val winner: Int = -1,
    val endReason: EndReason = EndReason.NONE
) {
    val boardEmpty: Boolean get() = left < 0

    /** Kartu yang belum terlihat = bukan di papan dan bukan di tangan kita => ada di tangan lawan. */
    fun unseen(): Int = Tiles.ALL and played.inv() and myHand.inv()

    /** Angka yang PASTI tidak dimiliki pemain p (dari riwayat pass). */
    fun forbiddenNumbers(p: Int): Set<Int> {
        val out = sortedSetOf<Int>()
        for (pr in passes) {
            if (pr.player == p) {
                if (pr.left >= 0) out.add(pr.left)
                if (pr.right >= 0) out.add(pr.right)
            }
        }
        return out
    }
}
