package com.domino.engine.vision

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import java.util.concurrent.Executor

class ScanOutcome(
    val mask: Int,
    val tiles: List<ScannedTile>,
    val problems: List<String>,
    val error: String?
)

/**
 * Ambil screenshot lewat AccessibilityService.takeScreenshot (Android 11+): tanpa dialog rekam layar,
 * tanpa internet, tidak ada gambar yang disimpan atau dikirim. Bitmap hanya diproses di memori lalu dibuang.
 */
object ScreenGrabber {

    private fun fail(msg: String) = ScanOutcome(0, emptyList(), emptyList(), msg)

    fun grab(svc: AccessibilityService, exec: Executor, cb: (ScanOutcome) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            cb(fail("Scan layar butuh Android 11 ke atas"))
            return
        }
        try {
            svc.takeScreenshot(
                Display.DEFAULT_DISPLAY,
                exec,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        var outcome: ScanOutcome = fail("Screenshot belum diproses")
                        try {
                            val hb = result.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                            if (hw == null) {
                                hb.close()
                                outcome = fail("Screenshot kosong")
                            } else {
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                hb.close()
                                outcome = if (soft == null) fail("Gagal menyalin screenshot") else analyze(soft)
                                soft?.recycle()
                            }
                        } catch (e: Throwable) {
                            outcome = fail("Gagal memproses screenshot: " + e.message)
                        }
                        cb(outcome)
                    }

                    override fun onFailure(errorCode: Int) {
                        val hint = when (errorCode) {
                            3 -> "terlalu cepat, coba lagi sebentar"
                            5 -> "layar ini diblokir game (secure window)"
                            else -> "kode $errorCode"
                        }
                        cb(fail("Screenshot gagal: $hint"))
                    }
                }
            )
        } catch (e: Throwable) {
            cb(fail("Tidak bisa ambil screenshot: " + e.message))
        }
    }

    private fun analyze(bmp: Bitmap): ScanOutcome {
        val w = bmp.width
        val h = bmp.height
        // coba pita bawah dulu (tangan biasanya di sini), lalu pita lebih tinggi
        val tops = doubleArrayOf(0.55, 0.38)
        for (top in tops) {
            val y0 = (h * top).toInt()
            val y1 = (h * 0.98).toInt()
            val bh = y1 - y0
            if (bh <= 0) continue
            val px = IntArray(w * bh)
            bmp.getPixels(px, 0, w, 0, y0, w, bh)
            val r = HandScanner.scan(px, w, bh, h)
            if (r.tiles.isNotEmpty()) return ScanOutcome(r.mask, r.tiles, r.problems, null)
        }
        return fail("Kartu tidak terlihat. Pastikan 7 kartu tampil di layar lalu scan lagi.")
    }
}
