package com.domino.engine.vision

import com.domino.engine.core.Tiles
import kotlin.math.abs
import kotlin.math.max

/** Satu kartu yang terbaca di tangan. a = titik bagian atas, b = titik bagian bawah. */
class ScannedTile(
    val x0: Int,
    val x1: Int,
    val a: Int,
    val b: Int,
    val valid: Boolean
)

class ScanResult(
    val tiles: List<ScannedTile>,
    val mask: Int,
    val problems: List<String>
)

/**
 * Pembaca kartu tangan 100% offline, tanpa model / OpenCV. Hanya hitung piksel:
 *  1. klasifikasi piksel: krem (badan kartu), merah (titik/garis)
 *  2. kolom yang banyak krem+merah = satu kartu (celah hijau = pemisah)
 *  3. tinggi kartu dari tengah-lebar kartu (toleran terhadap garis tengah)
 *  4. tiap setengah kartu: hitung gumpalan merah berbentuk bulat = jumlah titik
 * Sudah dicoba di screenshot nyata (7 kartu terbaca benar) dan tahan skala 0.67x-1.5x, JPEG, blur, kecerahan 75%-110%.
 * Kartu tegak (vertikal) seperti di game contoh. Tidak ada angka yang dikarang: kalau tidak yakin, kartu ditandai.
 */
object HandScanner {

    private fun isCream(r: Int, g: Int, b: Int): Boolean =
        r >= 165 && g >= 165 && b >= 125 && (r - b) >= 8 && (r - b) <= 75 && abs(r - g) <= 16

    private fun isRed(r: Int, g: Int, b: Int): Boolean =
        r >= 80 && r >= g + 45 && r >= b + 45

    /**
     * @param px piksel ARGB untuk PITA bawah layar (bandH baris, lebar w)
     * @param fullH tinggi layar penuh (untuk ambang)
     */
    fun scan(px: IntArray, w: Int, bandH: Int, fullH: Int): ScanResult {
        val total = w * bandH
        val cls = ByteArray(total)
        for (i in 0 until total) {
            val p = px[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            if (isCream(r, g, b)) cls[i] = 1 else if (isRed(r, g, b)) cls[i] = 2
        }

        // 1) profil kolom
        val col = IntArray(w)
        for (y in 0 until bandH) {
            val base = y * w
            for (x in 0 until w) {
                if (cls[base + x].toInt() != 0) col[x] = col[x] + 1
            }
        }
        val thr = max(1, (fullH * 0.10).toInt())
        val runs = ArrayList<IntArray>()
        var x = 0
        while (x < w) {
            if (col[x] >= thr) {
                val s = x
                while (x < w && col[x] >= thr) x++
                runs.add(intArrayOf(s, x - 1))
            } else {
                x++
            }
        }
        val merged = ArrayList<IntArray>()
        for (rr in runs) {
            if (merged.isNotEmpty() && rr[0] - merged[merged.size - 1][1] <= 3) {
                merged[merged.size - 1][1] = rr[1]
            } else {
                merged.add(intArrayOf(rr[0], rr[1]))
            }
        }
        val minW = (w * 0.025).toInt()

        val tiles = ArrayList<ScannedTile>()
        val problems = ArrayList<String>()
        var mask = 0

        for (m in merged) {
            val x0 = m[0]
            val x1 = m[1]
            val tw = x1 - x0 + 1
            if (tw < minW) continue

            // 2) tinggi kartu dari 60% tengah lebarnya
            val cx0 = x0 + (tw * 0.2).toInt()
            val cx1 = x1 - (tw * 0.2).toInt()
            if (cx1 < cx0) continue
            val rows = IntArray(bandH)
            for (y in 0 until bandH) {
                var c = 0
                val base = y * w
                for (xx in cx0..cx1) {
                    if (cls[base + xx].toInt() != 0) c++
                }
                rows[y] = c
            }
            val need = (cx1 - cx0 + 1) * 0.5
            val gap = max(3, (tw * 0.12).toInt())
            var bs = -1
            var be = -1
            var y = 0
            while (y < bandH) {
                if (rows[y] >= need) {
                    val s0 = y
                    var last = y
                    y++
                    while (y < bandH && (rows[y] >= need || y - last <= gap)) {
                        if (rows[y] >= need) last = y
                        y++
                    }
                    if (bs < 0 || (last - s0) > (be - bs)) {
                        bs = s0
                        be = last
                    }
                } else {
                    y++
                }
            }
            if (bs < 0) continue
            val th = be - bs + 1

            // 3) titik atas / bawah
            val a = countPips(cls, w, x0, x1, bs, be, 0)
            val b = countPips(cls, w, x0, x1, bs, be, 1)
            val ratio = th.toDouble() / tw
            var ok = a in 0..6 && b in 0..6
            if (ratio < 1.4 || ratio > 2.8) {
                ok = false
                problems.add("kartu ke-" + (tiles.size + 1) + " bentuknya tidak biasa")
            }
            if (!ok && a >= 0 && b >= 0 && ratio in 1.4..2.8) {
                problems.add("kartu ke-" + (tiles.size + 1) + " titiknya tidak jelas (" + a + "|" + b + ")")
            }
            if (ok) {
                val idx = Tiles.index(a, b)
                if (((mask shr idx) and 1) == 1) {
                    ok = false
                    problems.add("kartu " + Tiles.label(idx) + " terbaca dobel")
                } else {
                    mask = mask or (1 shl idx)
                }
            }
            tiles.add(ScannedTile(x0, x1, a, b, ok))
        }
        if (tiles.size > 7) problems.add("terbaca " + tiles.size + " kartu (lebih dari 7)")
        return ScanResult(tiles, mask, problems)
    }

    /** half 0 = bagian atas, 1 = bagian bawah. Mengembalikan jumlah titik, atau -1 kalau area tidak valid. */
    private fun countPips(cls: ByteArray, w: Int, x0: Int, x1: Int, y0: Int, y1: Int, half: Int): Int {
        val tw = x1 - x0 + 1
        val th = y1 - y0 + 1
        val mid = (y0 + y1) / 2
        val ix = (tw * 0.08).toInt()
        val ys: Int
        val ye: Int
        if (half == 0) {
            ys = y0 + (th * 0.10).toInt()
            ye = mid - (th * 0.045).toInt()
        } else {
            ys = mid + (th * 0.045).toInt()
            ye = y1 - (th * 0.05).toInt()
        }
        val xs = x0 + ix
        val xe = x1 - ix
        val hh = ye - ys + 1
        val ww = xe - xs + 1
        if (hh <= 0 || ww <= 0) return -1

        val n = hh * ww
        val mask = BooleanArray(n)
        for (yy in 0 until hh) {
            val base = (ys + yy) * w + xs
            for (xx in 0 until ww) {
                mask[yy * ww + xx] = cls[base + xx].toInt() == 2
            }
        }
        val seen = BooleanArray(n)
        val stack = IntArray(n)
        val minA = 0.012 * tw * tw
        val maxA = 0.16 * tw * tw
        var count = 0
        for (start in 0 until n) {
            if (!mask[start] || seen[start]) continue
            var sp = 0
            stack[sp] = start
            sp++
            seen[start] = true
            var area = 0
            var minx = ww
            var maxx = -1
            var miny = hh
            var maxy = -1
            while (sp > 0) {
                sp--
                val cur = stack[sp]
                area++
                val cy = cur / ww
                val cx = cur % ww
                if (cx < minx) minx = cx
                if (cx > maxx) maxx = cx
                if (cy < miny) miny = cy
                if (cy > maxy) maxy = cy
                if (cy + 1 < hh) {
                    val q = cur + ww
                    if (mask[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cy > 0) {
                    val q = cur - ww
                    if (mask[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cx + 1 < ww) {
                    val q = cur + 1
                    if (mask[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
                if (cx > 0) {
                    val q = cur - 1
                    if (mask[q] && !seen[q]) { seen[q] = true; stack[sp] = q; sp++ }
                }
            }
            val bw = maxx - minx + 1
            val bh = maxy - miny + 1
            val aspect = bw.toDouble() / bh
            if (area >= minA && area <= maxA && aspect >= 0.55 && aspect <= 1.8 && area >= 0.3 * bw * bh) {
                count++
            }
        }
        return count
    }
}
